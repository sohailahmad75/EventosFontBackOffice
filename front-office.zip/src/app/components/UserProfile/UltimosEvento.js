import React from "react";

const UltimosEvento = () => {

  return (
    <section className="container-fluid pl-0 pl-3 mt-3 mt-md-5">
      <div className="row">
        <div className="col-12 col-md-9 offset-0 offset-md-3 mt-5">
          <h1 className="display-1 pl-0 pl-md-5">Próximos eventos</h1>
        </div>
      </div>
      <div className="row mt-5">
        <div className="col-12 col-md-3 text-left text-md-center mb-2 mb-md-0">
          <p className='heading-with-line-gray'>COMING UP</p>
        </div>
        <div className="col-12 col-md-9 ">
          <div className="row flex-nowrap overflow-hidden">
                <div className="col-md-6 col-xl-4 col-12 pl-0 pl-md-5">
                 sdrfsd
                </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default UltimosEvento;
